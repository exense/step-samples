context('Opencart', () => {

  it('Opencart_TC01_PlaceOrder', () => {
    // Custom command defined in cypress/support/commands.js
    cy.Opencart_PlaceOrder()
  })

})

